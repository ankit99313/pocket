<?php
$login=true;
$showError=false;
if ($_SERVER["REQUEST_METHOD"]=="POST") {

require 'partials/_dbconnect.php';
$username=$_POST["username"];
$password=$_POST["password"];

//$sql="Select * from users where username='$username' AND password='$password'";
$sql="Select * from users where username='$username'";

    $result=mysqli_query($conn,$sql);
    $num=mysqli_num_rows($result);
    if ($num==1) {
      while($row=mysqli_fetch_assoc($result)){
       
        if($password==$row['password']) {
            $login=true;
            session_start();
            $_SESSION['loggedin']=true;
            $_SESSION['username']=$username;
            header("location:showquestion.php");
    }
    else{
      echo'alert("Hello! I am an alert box 1!")';
      $login=false;
    }
  }
}
    else {
      //$showError="password do not match";
      echo'alert("Hello! I am an alert box 2!")';
      $login=false;
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    
<div class="container">
   <h1  class="text-center">Login</h1>
  
   <form action="/pocket/index.php" method="post">
  <div class="form-group col-md-6">
    <label for="username">User name</label>
    <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp" placeholder="Enter your email">
    
  </div>
  <div class="form-group col-md-6">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
  
  
  <button type="submit" class="btn btn-primary col-md-6">Login</button>
</form>
</div>


</body>
</html>