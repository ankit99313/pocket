


<?php


    session_start();

    if (!isset($_SESSION['loggedin'])|| $_SESSION['loggedin']!=true) {
      header("location: index.php");
      exit;
    }

    if ($_SERVER["REQUEST_METHOD"]=="POST") {
    require 'partials/_dbconnect.php';

   $branch=$_POST["branch"];
   $year=$_POST["year"];
   $semester=$_POST["semester"];
   $subject=$_POST["subject"];
   $question=$_POST["question"];
   $answer=$_POST["answer"];
   $questionid=$_POST["questionid"];

   if($branch=="Mechanical"){

    $sql="INSERT INTO `mechanical` (`Id`, `branch`, `year`, `semester`, `subject`, `question`, `answer`, `date`) VALUES ('$questionid', '$branch', '$year', '$semester', '$subject', '$question', '$answer', current_timestamp())";

    
    $result=mysqli_query($conn,$sql);

    if ($result) {
       echo"<script>
       alert('Question added successfully');
       window.location.href='/pocket/showquestion.php';
       </script>";
       //header("location: showquestion.php");
    }
   }

   if($branch=="Civil"){

    
    $sql="INSERT INTO `Civil` (`Id`, `branch`, `year`, `semester`, `subject`, `question`, `answer`, `date`) VALUES ('$questionid', '$branch', '$year', '$semester', '$subject', '$question', '$answer', current_timestamp())";

    
    $result=mysqli_query($conn,$sql);
    
    if ($result) {
       echo"<script>
       alert('Question added successfully');
       window.location.href='/pocket/showquestion.php';
       </script>";
       //header("location: showquestion.php");
    }

   }

   if($branch=="Electrical"){

    
    $sql="INSERT INTO `Electrical` (`Id`, `branch`, `year`, `semester`, `subject`, `question`, `answer`, `date`) VALUES ('$questionid', '$branch', '$year', '$semester', '$subject', '$question', '$answer', current_timestamp())";

    
    $result=mysqli_query($conn,$sql);
    
    if ($result) {
       echo"<script>
       alert('Question added successfully');
       window.location.href='/pocket/showquestion.php';
       </script>";
       //header("location: showquestion.php");
    }

   }

   if($branch=="CSE"){

    
    $sql="INSERT INTO `CSE` (`Id`, `branch`, `year`, `semester`, `subject`, `question`, `answer`, `date`) VALUES ('$questionid', '$branch', '$year', '$semester', '$subject', '$question', '$answer', current_timestamp())";

    
    $result=mysqli_query($conn,$sql);
    
    if ($result) {
       echo"<script>
       alert('Question added successfully');
       window.location.href='/pocket/showquestion.php';
       </script>";
       //header("location: showquestion.php");
    }

   }

    }

   ?>

<!doctype html>
<html>
<head> <title> pocket question </title> 

<style> 
form {color: green; font-family: arial; font-size: 150%}

</style>


</head>
<body>

<h1 style="color:red;"> POCKET QUESTION </h1>
<h2 style="color:blue;"> UPLOAD QUESTION </h2>


<form action="/pocket/showquestion.php" method="POST">
Question ID : <input type="text" placeholder="eg. M/14/RAC/01/a" name="questionid">
<label for="branch">Branch:</label>

<select name="branch" id="branch">
  <option value="Mechanical">Mechanical</option>
  <option value="Civil">Civil</option>
  <option value="Electrical">Electrical</option>
  <option value="CSE">CSE</option>
</select>


Year : <input type="number" name="year" required>
Semester : <input type="number" name="semester" required>
Subject : <input type="text" name="subject" required>

<button> <a href="/pocket/logout.php">Logout</a></button>




<table> 
<tr>
<td>Question:</td><br>
				<td><textarea cols="150" rows="10" name="question" required></textarea></td>
</tr>
<br> <br>
<tr>
<td>Answer:</td><br>
				<td><textarea cols="150" rows="10" name="answer" required></textarea></td>
</tr>
</table>
<br><button type="submit" >SUBMIT </button>
</form>



</body>
</hltml>